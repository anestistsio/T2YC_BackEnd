package com.ots.T2YC_SPRING;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T2YcSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
