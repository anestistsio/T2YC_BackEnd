package com.ots.T2YC_SPRING.entities;

public enum Availabilities {
    AVAILABLE,
    BUSY,
    AWAY;
}
