package com.ots.T2YC_SPRING.entities;

public enum ChatStatus {
    NEVER_STARTED,
    ON_GOING,
    FINISHED;
}
