package com.ots.T2YC_SPRING.entities;

public interface MessageSender {
    int getId();
    String getFirstName();
    String getLastName();
    String getEmail();
    Role getRole();
}
